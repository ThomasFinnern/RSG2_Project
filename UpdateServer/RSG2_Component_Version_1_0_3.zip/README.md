# RSG2_Component_NextGeneration
An attempt to rewrite the component of RSGallery2 with MVC recommended by Jommla 3.x (?2.5 legacy)
