#
# update 1.0.1 sql for RSGallery2
#
