<?php // no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );?>

class Rsg2SummaryTreeViewHtml
{
	function DisplayAllGelleries ($xxx)
	{
	
	
	
	}




	function DisplayGallery ($gallery, $Nesting=0)
	{
	
	
	}

	function DisplayImage ($image,  $Nesting=0)
	{
	
	
	}


	
	
	
	
	
	

}