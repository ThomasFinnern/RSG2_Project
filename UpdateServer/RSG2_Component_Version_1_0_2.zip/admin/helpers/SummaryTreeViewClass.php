<?php // no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );?>

class Rsg2SummaryTreeViewClass
{




}


