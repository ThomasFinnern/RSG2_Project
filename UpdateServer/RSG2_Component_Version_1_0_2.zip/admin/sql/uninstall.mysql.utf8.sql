#
# uninstall sql for RSGallery2
#


#DROP TABLE IF EXISTS `#__rsgallery2_dummy_is_eaten`;
#DROP TABLE IF EXISTS `#__rsgallery2_galleries`;
#DROP TABLE IF EXISTS `#__rsgallery2_files`;
#DROP TABLE IF EXISTS `#__rsgallery2_comments`;
#DROP TABLE IF EXISTS `#__rsgallery2_config`;
#DROP TABLE IF EXISTS `#__rsgallery2_acl`;


